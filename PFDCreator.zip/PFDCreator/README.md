# README - Project PFDCreator, Copyright (c)2024 Robert W.B. Linn, Pinneberg, Germany.

## Information
[b]PFDCreator[/b] is an application to create all kind of simple [b]P[/b]rocess [b]F[/b]low [b]D[/b]iagrams (PFDs) using objects (shapes) which are dragged & dropped on a Drawing Board (Canvas).
A PFD contains objects which are shapes with properties.
The properties define the object shape position, size, colors, text & format, but also its value, unit, operate flag and more.
There are a number of predefined shapes, the basic shapes but also dedicated shape types to create flowcharts, process instrumentation & piping diagrams or electrical circuits.

[b]PFD Shape Types[/b]
The PFDCreator has initially following shape types:
[LIST]
[*] Basic - Common shapes which can be used by all PFD types.
[*] Flowchart - Shapes, like terminator, process, decision used to create flowcharts.
[*] PID - Shapes for Process Instrumentation & Piping (PID) diagrams.
[*] Electrical - Shapes to create electrical circuit diagrams.
[/LIST]

[b]Notes[/b]
[LIST]
[*]The PFDCreator application is provided as a B4J project with source code which requires [B4J IDE](https://www.b4x.com/b4j.html) to run (Windows).
[*]The PFDCreator has been evolved from the idea to create simple PIDs. The application has become rather complex and has room for improvements.
[*]The included predefined shapes, created as methods use different ways to draw on the canvas. This is because drawing shapes has been evolved.
[*]To enhance the PFDCreator with more shape types and shapes, lookup the development notes (DEVNOTES.md). 
[*]This B4J project is provided AS-IS, developments are ongoing which might lead to concept or code changes.
[/LIST]

## Documentation (application folder)
[LIST]
[*]DEVNOTES.MD - Comprehensive information about the PFDCreator concept, development and how to enhance.
[*]TODO.md - Actions for the next version.
[*]IDEAS.md - Ideas to be considered for implemention.
[*]CHANGELOG.md - Log of version changes.
[*]PFDCreator.hlp - User guide.
[/LIST]

## Installation B4J Project PFDCreator
Unzip the file pfdcreator.zip to a folder of choice.
Copy the library AsyncCanvas, jReflection located in the folder AdditionalLibraries to the B4J additional libraries folder.
Open the B4J IDE and load the project PFDCreator.b4j from the B4J folder.

## Video
A video showing how to create a very simple flowchart.
https://1drv.ms/v/s!AhNDg9iSqrdPwNBaM2PtGa6EUXKNIw

## Licence
GNU General Public License v3.0 - Developed for personal use only.
See file LICENSE.
